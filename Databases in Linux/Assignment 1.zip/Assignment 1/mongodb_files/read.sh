db.bank_accounts.find()
db.bank_accounts.find({first_name: "Larss"})
db.bank_accounts.find({"holding": 667})
db.bank_accounts.find({"id": 667})