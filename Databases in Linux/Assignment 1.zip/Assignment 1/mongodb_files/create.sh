db.bank_accounts.count()
db.bank_accounts.insertOne(
    {
        id: 1001,
        first_name: "Larss",
        last_name: "Dsves",
        holding: 667
    }
    )
db.bank_accounts.count()