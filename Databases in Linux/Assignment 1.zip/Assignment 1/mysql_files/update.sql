SELECT *
FROM bank_accounts
WHERE holding = 666;

UPDATE bank_accounts
set holding = 666
WHERE id = 666;

SELECT *
FROM bank_accounts
WHERE holding = 666;