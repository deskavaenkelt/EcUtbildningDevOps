insert into bank_accounts (first_name, last_name, holding)
values ('Lars', 'Dsve', 666);
