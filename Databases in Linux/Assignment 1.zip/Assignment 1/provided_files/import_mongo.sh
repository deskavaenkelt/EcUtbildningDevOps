mongoimport --db bank --collection bank_accounts --file ./bank_accounts.json --jsonArray
