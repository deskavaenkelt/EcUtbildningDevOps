import black_jack

print(__name__)
black_jack.play()

personal_details = ('Something', 24, 'Sweden')

name, _, country = personal_details
print(name, country)
print(_)
